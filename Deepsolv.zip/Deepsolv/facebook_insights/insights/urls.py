from django.urls import path
from .views import PageDetailView
from django.http import JsonResponse

# Add a default API landing route
def api_home(request):
    return JsonResponse({"message": "Welcome to Facebook Insights API!"})

urlpatterns = [
    path('', api_home, name='api-home'),  # This will handle /api/
    path('page/<str:username>/', PageDetailView.as_view(), name='page-detail'),
]
