import requests
from bs4 import BeautifulSoup

def scrape_facebook_page(username):
    url = f"https://www.facebook.com/{username}"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    # Extract details
    page_data = {
        "name": soup.find("meta", property="og:title")["content"],
        "url": url,
        "profile_pic": soup.find("meta", property="og:image")["content"],
        # Add more scraping logic as needed
    }
    return page_data
