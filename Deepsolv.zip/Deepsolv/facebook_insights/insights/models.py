from django.db import models

# Create your models here.
class Page(models.Model):
    page_id = models.CharField(max_length=255, unique=True)
    name = models.CharField(max_length=255)
    username = models.CharField(max_length=255, unique=True)
    url = models.URLField()
    profile_pic = models.URLField()
    email = models.EmailField(null=True, blank=True)
    website = models.URLField(null=True, blank=True)
    category = models.CharField(max_length=255, null=True, blank=True)
    total_followers = models.IntegerField(null=True, blank=True)  # Allow NULL values
    total_likes = models.IntegerField(null=True, blank=True)
    created_at = models.DateTimeField(null=True, blank=True)

class Post(models.Model):
    page = models.ForeignKey(Page, on_delete=models.CASCADE)
    post_id = models.CharField(max_length=255, unique=True)
    content = models.TextField()
    likes = models.IntegerField()
    comments_count = models.IntegerField()
    created_at = models.DateTimeField()

class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    comment_id = models.CharField(max_length=255, unique=True)
    text = models.TextField()
    user_name = models.CharField(max_length=255)
    created_at = models.DateTimeField()

class Follower(models.Model):
    page = models.ForeignKey(Page, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    profile_pic = models.URLField()

