from django.shortcuts import render

# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Page, Post, Comment
from .scraper import scrape_facebook_page

class PageDetailView(APIView):
    def get(self, request, username):
        try:
            page = Page.objects.get(username=username)
        except Page.DoesNotExist:
            # If page not in DB, scrape and store it
            data = scrape_facebook_page(username)
            page = Page.objects.create(**data)
        
        return Response({
            "name": page.name,
            "url": page.url,
            "profile_pic": page.profile_pic,
        }, status=status.HTTP_200_OK)

